<!-- inner page banner --> 	
<div class="innerpage-banner">
	<div class="layer1">
	</div>
</div>

<!-- welcome -->
<section class="welcome py-5">
	<div class="container py-3">
	<h3 class="heading text-center mb-md-5 mb-4"> Tentang Kami </h3>
		<div class="row welcome-grids">
			<div class="col-lg-6">
				<h4 class="mb-3">Selamat Datang di Tikotu Agency</h4>
				<h3>Ingatlah bahwa kebahagiaan adalah cara dalam perjalanan, bukan tujuan akhir.</h3>
				<p class="my-4">Temukan pemandu wisata Anda dalam hitungan detik dan jelajahi dunia. Anda dapat meminta pemandu wisata untuk tur pribadi Anda atau memesan tur siap pakai yang disediakan oleh pemandu wisata kami. Setiap pemandu wisata dapat menjelaskan wilayah mereka dengan cermat dan sabar untuk mempelajari budaya dan pengalaman di daerah tersebut.</p>
				<p>
					<i class="fa fa-check text-orange mr-2"></i> Certificated Local Tour Guides Support.
					<br>
					<i class="fa fa-check text-orange mr-2"></i> Checked Every Tour Route.
					<br>
					<i class="fa fa-check text-orange mr-2"></i> Since 2015.
				</p>
			</div>
			<div class="col-lg-6 mt-lg-0 mt-5 welcome-grid3">
				<div class="position">
					<img src="<?php echo base_url(); ?>assets/frontend/images/banner4.jpg" alt="" class="img-fluid" />
				</div>
			</div>
		</div>
	</div>
</section>
<!-- //welcome -->

<!-- welcome bottom -->
<section class="welcome-bottom">
	<div class="welcome-bottom-layer py-5">
		<div class="container py-lg-5 py-sm-3">
		<h4 class="mb-2">Perjalanan tidak akan menjadi petualangan sampai Anda meninggalkan diri Anda sendiri</h4>
		<p class="mb-4">Temukan tur sempurna Anda</p>
		<a href="<?= base_url().'index.php/Tour/showall' ?>">Lihat Semua Tur</a>
		</div>
	</div>
</section>

<!-- welcome -->
<section class="welcome py-5">
	<div class="container py-3">
		<div class="row welcome-grids">
			<div class="col-lg-6 mt-lg-0 mt-5 welcome-grid3">
				<div class="position">
					<img src="<?php echo base_url(); ?>assets/frontend/images/banner2.jpg" alt="" class="img-fluid" />
				</div>
			</div>
			<div class="col-lg-6">
				<h3 class="mt-3">Mengapa Tikotu</h3>
				<p class="my-4">Tikotu adalah platform online yang memungkinkan para pelancong berinteraksi dengan pemandu di seluruh dunia. Di sini, para pelancong dapat melihat profil pemandu, menghubungi, dan melakukan pemesanan langsung dengan mereka!</p>
				<p>
					Komunitas pemandu yang terdaftar di kami telah berkembang menjadi sekitar 1.500 pemandu, di lebih dari 50 kota dari 68 negara di seluruh dunia! Ini menjadikan kami salah satu komunitas pemandu terbesar dan terluas di dunia.
				</p>

			</div>
		</div>
	</div>
</section>