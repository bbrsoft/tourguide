<?php  

	class Service extends CI_Controller
	{
		public function index()
		{
			$this->load->helper(array('form', 'url'));
			$this->load->library('form_validation');
			
			$data['fiturlist'] = $this->Fitur_mdl->fiturlist();
			$data['innerdata'] = 'fitur_list';
			$data['todaytourlist'] = $this->Tour_mdl->todaytourlist();
			$data['notidata'] = 'adminnoti_tour';
			$this->load->view('stafftemplate', $data);
		}

		public function store()
		{
			$this->form_validation->set_rules('name', 'name', 'required|is_unique[fitur.name]', array('is_unique' => 'This Name is already Existed!'));
			$this->form_validation->set_rules('type', 'fiturType', 'required', array('required' => 'Please Choose fitur Type!'));

			 if ($this->form_validation->run() == FALSE)
            {
				$data['innerdata'] = 'fitur_add';
				$data['todaytourlist'] = $this->Tour_mdl->todaytourlist();
				$data['notidata'] = 'adminnoti_tour';
				$this->load->view('stafftemplate', $data);
            }
            else
            {
                $this->Fitur_mdl->store();
				redirect(base_url() . 'index.php/service');
            }
		}

		public function add()
		{
			$data['innerdata'] = 'fitur_add';
			$data['todaytourlist'] = $this->Tour_mdl->todaytourlist();
			$data['notidata'] = 'adminnoti_tour';
			$this->load->view('stafftemplate', $data);
		}

		public function edit()
		{
			$id = $this->uri->segment(3);
			$data['editfitur'] = $this->Fitur_mdl->edit($id);
			$data['innerdata'] = 'fitur_edit';
			$data['todaytourlist'] = $this->Tour_mdl->todaytourlist();
			$data['notidata'] = 'adminnoti_tour';
			$this->load->view('stafftemplate', $data);
		}

		public function update()
		{
			$this->Fitur_mdl->update();
			redirect(base_url() . 'index.php/service');
		}

		public function delete()
		{
			$id = $this->uri->segment(3);
			$this->Fitur_mdl->delete($id);
			redirect(base_url() . 'index.php/service');
		}		
	}
?>